#!/usr/bin/env python

def softwares():
    return {
        "intellij": "",
        "atom": "",
        "maven": ""
    }

def process():
    for k,v in softwares().items():
        print("installing "+ k)


if __name__ == "__main__":
    process()